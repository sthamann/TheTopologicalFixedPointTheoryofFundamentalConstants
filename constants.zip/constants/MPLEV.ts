// Planck mass (GeV)
